#ifndef FORMULAS_H
#define FORMULAS_H

float formula1(float *x, unsigned int length);
float formula2(float *x, float *y, unsigned int length);

#endif